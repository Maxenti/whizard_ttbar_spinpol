# QIS next production gate + Spin-15 validation

This bundle is based on the current repository state after:

1. `qis_key4hep_idempotent_setup_fix.patch`
2. `qis_pythia_hepmc_weight_and_build_fix.patch`
3. `qis_whizard_lhe_sanitization_and_stage_diagnostics_fix.patch`
4. installation of canonical LHA v2 and explicit-W v3 helpers

## Preferred installation

From the repository root:

```bash
patch --dry-run -p1 < qis_next_production_gate_spin15.patch
patch -p1 < qis_next_production_gate_spin15.patch
```

Then validate:

```bash
source setup_lxplus.sh
python3 -m pytest -q tests/qis
bash -n \
  scripts/showering/run_pythia_shard.sh \
  scripts/qis/run_next_production_gate.sh \
  scripts/qis/run_spin15_qualification_gate.sh
```

## Overlay installation

The `overlay/` directory contains only the files added or replaced by this
bundle.  Copy it onto the repository only after making a backup:

```bash
cp -a overlay/. /afs/cern.ch/user/c/cglenn/FCCWork/whizard/whizard_ttbar_spinpol/
```

## First command

```bash
scripts/qis/run_next_production_gate.sh preflight
```

See `docs/qis/SPIN15_VALIDATION.md` after installation.
